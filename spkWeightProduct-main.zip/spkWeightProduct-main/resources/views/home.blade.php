@extends('layouts.global')
@section('title','Dashboard')

@section('content')
  <!-- Main content -->
  <section class="content">
    <div class="box box-default">
      <div class="box-body">
        <div class="text-center">
          <br><br><br><br>
          <img src="{{asset('storage/gambars/drawing.png')}}" width="250px" alt="logo sekolah">
          <h2><b>SISTEM PENUNJANG KEPUTUSAN MENENTUKAN PELANGGAN TERBAIK<br>
          DENGAN PENDEKATAN METODE WEIGHTED PRODUCT</h2>
          <div class="home_social">
                   <p> <a href="#">Facebook</a> | <a href="#">Instagram</a> | <a href="#">LinkedIn</a></p>
          </div>
          <br><br>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </section>
@endsection
